import os
from openenv.env import WarehouseEnv

API_BASE_URL = os.getenv("API_BASE_URL")
MODEL_NAME = os.getenv("MODEL_NAME")
HF_TOKEN = os.getenv("HF_TOKEN")

env = WarehouseEnv()

print("[START]")

state = env.reset()
total_reward = 0

for step in range(50):
    action = 10
    state, reward, done, _ = env.step(action)
    total_reward += reward

    print(f"[STEP] step={step}, action={action}, reward={reward}")

print("[END]")
print("Final Score:", total_reward / 50)