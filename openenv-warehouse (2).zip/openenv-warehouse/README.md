# OpenEnv Warehouse Environment

## Description
This project simulates a warehouse inventory management system.
An AI agent decides how much stock to order based on demand.

## API
- step(action)
- reset()
- state()

## State
- inventory (int)
- demand (int)

## Action
- order (int)

## Reward
Reward is based on minimizing:
- overstock cost
- shortage cost

Range: 0.0 to 1.0

## Tasks
- Easy
- Medium
- Hard

## Results
Easy: ~0.93  
Medium: ~0.93  
Hard: ~0.93  

## Run
python inference.py