from env import WarehouseEnv

def easy_task():
    env = WarehouseEnv()
    state = env.reset()
    total = 0

    done = False
    while not done:
        state, reward, done, _ = env.step(10)
        total += reward

    return total / 30


def medium_task():
    env = WarehouseEnv()
    state = env.reset()
    total = 0

    done = False
    while not done:
        if state["stock"] < 30:
            action = 20
        else:
            action = 5

        state, reward, done, _ = env.step(action)
        total += reward

    return total / 30


def hard_task():
    env = WarehouseEnv()
    state = env.reset()
    total = 0

    done = False
    while not done:
        if state["stock"] < 20:
            action = 30
        elif state["stock"] > 70:
            action = 0
        else:
            action = 10

        state, reward, done, _ = env.step(action)
        total += reward

    return total / 30