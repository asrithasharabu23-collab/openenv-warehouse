import random

class WarehouseEnv:

    def __init__(self):
        self.max_steps = 30

    def reset(self):
        self.stock = 50
        self.day = 0
        return {"stock": self.stock, "day": self.day}

    def step(self, action):
        demand = random.randint(5, 20)

        self.stock += action
        sold = min(self.stock, demand)
        self.stock -= sold

        holding_cost = 0.1 * self.stock
        shortage_cost = 2 * max(0, demand - sold)

        reward = 1 - (holding_cost + shortage_cost) / 50
        reward = max(0, min(1, reward))

        self.day += 1
        done = self.day >= self.max_steps

        return {"stock": self.stock, "day": self.day}, reward, done, {}